'use strict';

const JWT_SECRET = 'token';

module.exports = {
  JWT_SECRET
};
